import "package:firebase_auth/firebase_auth.dart";
import "package:firebase_core/firebase_core.dart";
import "package:flutter/material.dart";
import "firebase_options.dart";
import "screens/home_shell.dart";
import "screens/login_screen.dart";
import "services/auth_service.dart";
import "theme.dart";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const SolarIotApp());
}

class SolarIotApp extends StatelessWidget {
  const SolarIotApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "SolarIoT",
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: const _AuthGate(),
    );
  }
}

// Swaps between Login and the main app shell based on Firebase Auth state -
// mirrors ProtectedRoute + AuthContext on the web app.
class _AuthGate extends StatelessWidget {
  const _AuthGate();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: AuthService().authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.hasData) {
          return const HomeShell();
        }
        return const LoginScreen();
      },
    );
  }
}
