class Reading {
  final int timestamp; // ms since epoch
  final double voltage;
  final double current;
  final double temperature;
  final double batteryPercent;
  final double power;

  Reading({
    required this.timestamp,
    required this.voltage,
    required this.current,
    required this.temperature,
    required this.batteryPercent,
    required this.power,
  });

  factory Reading.fromMap(Map<dynamic, dynamic> map) {
    return Reading(
      timestamp: (map["timestamp"] as num?)?.toInt() ?? 0,
      voltage: (map["voltage"] as num?)?.toDouble() ?? 0,
      current: (map["current"] as num?)?.toDouble() ?? 0,
      temperature: (map["temperature"] as num?)?.toDouble() ?? 0,
      batteryPercent: (map["batteryPercent"] as num?)?.toDouble() ?? 0,
      power: (map["power"] as num?)?.toDouble() ?? 0,
    );
  }
}

enum DeviceOnlineStatus { online, offline }

class DeviceStatus {
  final String name;
  final DeviceOnlineStatus status;

  DeviceStatus({required this.name, required this.status});
}

enum AlertLevel { info, warning, error }

AlertLevel alertLevelFromString(String? value) {
  switch (value) {
    case "warning":
      return AlertLevel.warning;
    case "error":
      return AlertLevel.error;
    default:
      return AlertLevel.info;
  }
}

class AppAlert {
  final String id;
  final int timestamp;
  final AlertLevel level;
  final String title;
  final String message;

  AppAlert({
    required this.id,
    required this.timestamp,
    required this.level,
    required this.title,
    required this.message,
  });

  factory AppAlert.fromMap(String id, Map<dynamic, dynamic> map) {
    return AppAlert(
      id: id,
      timestamp: (map["timestamp"] as num?)?.toInt() ?? 0,
      level: alertLevelFromString(map["level"] as String?),
      title: map["title"] as String? ?? "",
      message: map["message"] as String? ?? "",
    );
  }
}

class AppSettings {
  final double tempLimitC;
  final double batteryLowPct;
  final double readingIntervalSec;

  const AppSettings({
    required this.tempLimitC,
    required this.batteryLowPct,
    required this.readingIntervalSec,
  });

  static const defaults = AppSettings(
    tempLimitC: 45,
    batteryLowPct: 20,
    readingIntervalSec: 5,
  );

  factory AppSettings.fromMap(Map<dynamic, dynamic>? map) {
    if (map == null) return defaults;
    return AppSettings(
      tempLimitC: (map["tempLimitC"] as num?)?.toDouble() ?? defaults.tempLimitC,
      batteryLowPct: (map["batteryLowPct"] as num?)?.toDouble() ?? defaults.batteryLowPct,
      readingIntervalSec:
          (map["readingIntervalSec"] as num?)?.toDouble() ?? defaults.readingIntervalSec,
    );
  }

  Map<String, dynamic> toMap() => {
        "tempLimitC": tempLimitC,
        "batteryLowPct": batteryLowPct,
        "readingIntervalSec": readingIntervalSec,
      };

  AppSettings copyWith({double? tempLimitC, double? batteryLowPct, double? readingIntervalSec}) {
    return AppSettings(
      tempLimitC: tempLimitC ?? this.tempLimitC,
      batteryLowPct: batteryLowPct ?? this.batteryLowPct,
      readingIntervalSec: readingIntervalSec ?? this.readingIntervalSec,
    );
  }
}

class CircuitPoint {
  final double current;
  final double power;
  CircuitPoint({required this.current, required this.power});

  factory CircuitPoint.fromMap(Map<dynamic, dynamic>? map) {
    if (map == null) return CircuitPoint(current: 0, power: 0);
    return CircuitPoint(
      current: (map["current"] as num?)?.toDouble() ?? 0,
      power: (map["power"] as num?)?.toDouble() ?? 0,
    );
  }
}

// One reading covering all circuits at a point in time - mirrors
// /circuits/latest and /circuits/history entries written by the firmware.
class CircuitsReading {
  final int timestamp;
  final CircuitPoint? lights;
  final CircuitPoint? fan;
  final CircuitPoint? tv;
  final CircuitPoint? fridge;

  CircuitsReading({
    required this.timestamp,
    this.lights,
    this.fan,
    this.tv,
    this.fridge,
  });

  factory CircuitsReading.fromMap(Map<dynamic, dynamic> map) {
    return CircuitsReading(
      timestamp: (map["timestamp"] as num?)?.toInt() ?? 0,
      lights: map["lights"] != null ? CircuitPoint.fromMap(map["lights"]) : null,
      fan: map["fan"] != null ? CircuitPoint.fromMap(map["fan"]) : null,
      tv: map["tv"] != null ? CircuitPoint.fromMap(map["tv"]) : null,
      fridge: map["fridge"] != null ? CircuitPoint.fromMap(map["fridge"]) : null,
    );
  }
}
