import "dart:async";
import "package:firebase_database/firebase_database.dart";
import "../models/sensor_models.dart";

const _historyLimit = 50;
const _staleMs = 15000;
const _deviceNames = [
  "ESP32 Controller",
  "Solar Voltage Sensor",
  "Current Sensor",
  "Temperature Sensor",
  "Battery Monitor",
];

class SolarDataService {
  final DatabaseReference _root = FirebaseDatabase.instance.ref();

  // ---- Readings ----

  Stream<Reading?> latestReading() {
    return _root.child("readings/latest").onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return null;
      return Reading.fromMap(Map<dynamic, dynamic>.from(value as Map));
    });
  }

  Stream<List<Reading>> history() {
    final query = _root.child("readings/history").orderByKey().limitToLast(_historyLimit);
    return query.onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return <Reading>[];
      final map = Map<dynamic, dynamic>.from(value as Map);
      final list = map.values
          .map((v) => Reading.fromMap(Map<dynamic, dynamic>.from(v as Map)))
          .toList();
      list.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      return list;
    });
  }

  // ---- Devices (derived from ESP32 heartbeat) ----

  Stream<List<DeviceStatus>> devices() {
    return _root.child("system/lastSeen").onValue.map((event) {
      final lastSeen = event.snapshot.value;
      final online = lastSeen is num &&
          DateTime.now().millisecondsSinceEpoch - lastSeen.toInt() < _staleMs;
      final status = online ? DeviceOnlineStatus.online : DeviceOnlineStatus.offline;
      return _deviceNames.map((name) => DeviceStatus(name: name, status: status)).toList();
    });
  }

  // ---- Alerts ----

  Stream<List<AppAlert>> alerts() {
    final query = _root.child("alerts").orderByKey().limitToLast(50);
    return query.onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return <AppAlert>[];
      final map = Map<dynamic, dynamic>.from(value as Map);
      final list = map.entries
          .map((e) => AppAlert.fromMap(e.key as String, Map<dynamic, dynamic>.from(e.value as Map)))
          .toList();
      list.sort((a, b) => b.timestamp.compareTo(a.timestamp));
      return list;
    });
  }

  // Simple in-memory cooldown so the same threshold breach doesn't spam
  // duplicate alerts every reading - mirrors the web app's raiseAlert().
  final Map<String, int> _recentAlertKeys = {};
  static const _alertCooldownMs = 5 * 60 * 1000;

  Future<void> raiseAlert(String level, String title, String message) async {
    final key = "$level:$title";
    final now = DateTime.now().millisecondsSinceEpoch;
    final last = _recentAlertKeys[key];
    if (last != null && now - last < _alertCooldownMs) return;
    _recentAlertKeys[key] = now;

    final alertRef = _root.child("alerts").push();
    await alertRef.set({
      "level": level,
      "title": title,
      "message": message,
      "timestamp": now,
    });
  }

  // ---- Settings ----

  Stream<AppSettings> settings() {
    return _root.child("settings").onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return AppSettings.defaults;
      return AppSettings.fromMap(Map<dynamic, dynamic>.from(value as Map));
    });
  }

  Future<void> saveSettings(AppSettings settings) async {
    await _root.child("settings").set(settings.toMap());
  }

  // ---- Circuits (per-appliance - only present once CT sensors are wired up) ----

  Stream<CircuitsReading?> circuitsLatest() {
    return _root.child("circuits/latest").onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return null;
      return CircuitsReading.fromMap(Map<dynamic, dynamic>.from(value as Map));
    });
  }

  // null = no circuit sensors have ever reported - caller should show the
  // clearly-labeled simulated fallback instead of an empty real chart.
  Stream<List<CircuitsReading>?> circuitsHistory() {
    final query = _root.child("circuits/history").orderByKey().limitToLast(_historyLimit);
    return query.onValue.map((event) {
      final value = event.snapshot.value;
      if (value == null) return null;
      final map = Map<dynamic, dynamic>.from(value as Map);
      final list = map.values
          .map((v) => CircuitsReading.fromMap(Map<dynamic, dynamic>.from(v as Map)))
          .toList();
      list.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      return list;
    });
  }
}
