import "../models/sensor_models.dart";
import "solar_data_service.dart";

void checkThresholds(
  Reading reading,
  AppSettings settings,
  SolarDataService dataService,
) {
  if (reading.temperature > settings.tempLimitC) {
    dataService.raiseAlert(
      "warning",
      "High Temperature",
      "Temperature reached ${reading.temperature.toStringAsFixed(1)}°C "
          "(limit ${settings.tempLimitC.toStringAsFixed(0)}°C)",
    );
  }
  if (reading.batteryPercent < settings.batteryLowPct) {
    dataService.raiseAlert(
      "warning",
      "Low Battery",
      "Battery at ${reading.batteryPercent.toStringAsFixed(0)}% "
          "(alert below ${settings.batteryLowPct.toStringAsFixed(0)}%)",
    );
  }
  if (reading.voltage < 10) {
    dataService.raiseAlert(
      "error",
      "Low Solar Voltage",
      "Voltage dropped to ${reading.voltage.toStringAsFixed(2)}V",
    );
  }
}
