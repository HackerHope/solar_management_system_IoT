import "package:flutter/material.dart";
import "../models/sensor_models.dart";
import "../services/solar_data_service.dart";
import "../theme.dart";
import "../widgets/status_states.dart";

class SolarSystemScreen extends StatelessWidget {
  const SolarSystemScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dataService = SolarDataService();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text("Solar System Devices", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text("Connection overview of your solar system.", style: TextStyle(color: AppColors.textMuted)),
        const SizedBox(height: 16),
        StreamBuilder<Reading?>(
          stream: dataService.latestReading(),
          builder: (context, readingSnap) {
            return StreamBuilder<List<DeviceStatus>>(
              stream: dataService.devices(),
              builder: (context, devicesSnap) {
                final connected = (devicesSnap.data ?? []).isNotEmpty &&
                    devicesSnap.data!.every((d) => d.status == DeviceOnlineStatus.online);
                final latest = readingSnap.data;

                return Column(
                  children: [
                    _deviceCard("☀️", "Solar Panel",
                        latest != null ? "${latest.voltage.toStringAsFixed(1)} V" : "--", connected),
                    _deviceCard("⚡", "Charge Controller",
                        latest != null ? "${latest.current.toStringAsFixed(1)} A" : "--", connected),
                    _deviceCard("🔋", "Battery Monitor",
                        latest != null ? "${latest.batteryPercent.toStringAsFixed(0)}%" : "--", connected),
                    _deviceCard("🌡️", "Temperature Sensor",
                        latest != null ? "${latest.temperature.toStringAsFixed(0)}°C" : "--", connected),
                    _deviceCard("💡", "Load Controller", "No sensor yet", null),
                  ],
                );
              },
            );
          },
        ),
      ],
    );
  }

  // status: true = online, false = offline, null = not wired up (neutral color)
  Widget _deviceCard(String icon, String name, String value, bool? status) {
    final statusLabel = status == null ? "Not wired" : (status ? "Online" : "Offline");
    final statusColor = status == null
        ? AppColors.textMuted
        : (status ? AppColors.online : AppColors.offline);

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Panel(
        child: Row(
          children: [
            Text(icon, style: const TextStyle(fontSize: 28)),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
            Text(statusLabel, style: TextStyle(color: statusColor, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
