import "package:flutter/material.dart";
import "../models/sensor_models.dart";
import "../services/solar_data_service.dart";
import "../theme.dart";
import "../widgets/status_states.dart";

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _dataService = SolarDataService();
  AppSettings? _settings;
  bool _saving = false;
  DateTime? _savedAt;

  final _tempController = TextEditingController();
  final _batteryController = TextEditingController();
  final _intervalController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _dataService.settings().listen((s) {
      if (!mounted) return;
      setState(() {
        _settings = s;
        _tempController.text = s.tempLimitC.toStringAsFixed(0);
        _batteryController.text = s.batteryLowPct.toStringAsFixed(0);
        _intervalController.text = s.readingIntervalSec.toStringAsFixed(0);
      });
    });
  }

  @override
  void dispose() {
    _tempController.dispose();
    _batteryController.dispose();
    _intervalController.dispose();
    super.dispose();
  }

  Future<void> _handleSave() async {
    setState(() => _saving = true);
    try {
      final updated = AppSettings(
        tempLimitC: double.tryParse(_tempController.text) ?? AppSettings.defaults.tempLimitC,
        batteryLowPct: double.tryParse(_batteryController.text) ?? AppSettings.defaults.batteryLowPct,
        readingIntervalSec:
            double.tryParse(_intervalController.text) ?? AppSettings.defaults.readingIntervalSec,
      );
      await _dataService.saveSettings(updated);
      setState(() => _savedAt = DateTime.now());
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_settings == null) {
      return const LoadingState(label: "Loading settings...");
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text("Settings", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text("Configure system preferences.", style: TextStyle(color: AppColors.textMuted)),
        const SizedBox(height: 16),

        _settingField("Temperature Limit (°C)", _tempController),
        const SizedBox(height: 12),
        _settingField("Battery Low Alert (%)", _batteryController),
        const SizedBox(height: 12),
        _settingField("Reading Interval (seconds)", _intervalController),
        const SizedBox(height: 20),

        ElevatedButton(
          onPressed: _saving ? null : _handleSave,
          child: Text(_saving ? "Saving..." : "Save Settings"),
        ),
        if (_savedAt != null) ...[
          const SizedBox(height: 10),
          Text(
            "Saved at ${_savedAt!.hour.toString().padLeft(2, '0')}:${_savedAt!.minute.toString().padLeft(2, '0')}",
            style: const TextStyle(color: AppColors.textMuted, fontSize: 12),
          ),
        ],
      ],
    );
  }

  Widget _settingField(String label, TextEditingController controller) {
    return Panel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          TextField(
            controller: controller,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
        ],
      ),
    );
  }
}
