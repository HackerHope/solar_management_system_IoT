import "package:flutter/material.dart";
import "package:intl/intl.dart";
import "../models/sensor_models.dart";
import "../services/alert_thresholds.dart";
import "../services/solar_data_service.dart";
import "../theme.dart";
import "../widgets/alerts_panel.dart";
import "../widgets/device_status_panel.dart";
import "../widgets/power_chart.dart";
import "../widgets/sensor_line_chart.dart";
import "../widgets/stat_card.dart";
import "../widgets/status_states.dart";

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _dataService = SolarDataService();
  AppSettings _settings = AppSettings.defaults;

  @override
  void initState() {
    super.initState();
    _dataService.settings().listen((s) => _settings = s);
    // Side effect (writing alerts) belongs in a subscription, not build().
    _dataService.latestReading().listen((reading) {
      if (reading != null) checkThresholds(reading, _settings, _dataService);
    });
  }

  String _batteryStatusLabel(double pct) {
    if (pct < 20) return "Low";
    if (pct < 50) return "Fair";
    return "Healthy";
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Reading?>(
      stream: _dataService.latestReading(),
      builder: (context, latestSnap) {
        final latest = latestSnap.data;

        return RefreshIndicator(
          onRefresh: () async {},
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _TopBar(temperature: latest?.temperature),
              const SizedBox(height: 16),
              if (!latestSnap.hasData) const LoadingState(label: "Connecting to Firebase..."),

              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.5,
                children: [
                  StatCard(
                    icon: "🔋",
                    title: "Battery Level",
                    value: latest != null ? "${latest.batteryPercent.toStringAsFixed(0)}%" : "--",
                    status: latest != null ? _batteryStatusLabel(latest.batteryPercent) : "No data",
                  ),
                  StatCard(
                    icon: "☀️",
                    title: "Solar Voltage",
                    value: latest != null ? "${latest.voltage.toStringAsFixed(1)} V" : "--",
                    status: latest != null ? "Stable" : "No data",
                  ),
                  StatCard(
                    icon: "⚡",
                    title: "Load Current",
                    value: latest != null ? "${latest.current.toStringAsFixed(1)} A" : "--",
                    status: latest != null ? "Normal" : "No data",
                  ),
                  StatCard(
                    icon: "🌡️",
                    title: "Temperature",
                    value: latest != null ? "${latest.temperature.toStringAsFixed(0)}°C" : "--",
                    status: latest != null ? "Safe" : "No data",
                  ),
                ],
              ),
              const SizedBox(height: 16),

              StreamBuilder<List<Reading>>(
                stream: _dataService.history(),
                builder: (context, historySnap) {
                  final history = historySnap.data ?? [];
                  return Column(
                    children: [
                      SensorLineChart(data: history),
                      const SizedBox(height: 16),
                      PowerChart(data: history),
                    ],
                  );
                },
              ),
              const SizedBox(height: 16),

              StreamBuilder<List<AppAlert>>(
                stream: _dataService.alerts(),
                builder: (context, snap) => AlertsPanel(alerts: snap.data ?? [], limit: 3),
              ),
              const SizedBox(height: 16),

              StreamBuilder<List<DeviceStatus>>(
                stream: _dataService.devices(),
                builder: (context, snap) => DeviceStatusPanel(devices: snap.data ?? []),
              ),
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }
}

class _TopBar extends StatelessWidget {
  final double? temperature;
  const _TopBar({this.temperature});

  @override
  Widget build(BuildContext context) {
    final today = DateFormat("MMMM d, yyyy").format(DateTime.now());
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Expanded(
          child: Text("Dashboard", style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: const Color(0xFF111C30),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(today, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
              Text(
                temperature != null ? "${temperature!.toStringAsFixed(0)}°C" : "--°C",
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
